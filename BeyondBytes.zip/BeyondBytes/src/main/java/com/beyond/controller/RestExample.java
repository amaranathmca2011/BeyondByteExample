package com.beyond.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RestExample {

	
	
	@GetMapping("/hi")
	public String DisplayHi() {
		
		return "hi";
	}
}
